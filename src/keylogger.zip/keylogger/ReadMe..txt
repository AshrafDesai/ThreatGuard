Hello Friends,
		This Key Logger Is Made By Dr.Nick_Z,Anic
		This Is Just Only Eductional Perpouse.

		Don't Mis Use It ..
		I Am Not Responsible For That.....